export const DEFAULT_OPEN = false;
export const DEFAULT_CLASS_NAME = '';

export const MODAL_Z_INDEX = 'z-50';
export const ESCAPE_KEY = 'Escape';