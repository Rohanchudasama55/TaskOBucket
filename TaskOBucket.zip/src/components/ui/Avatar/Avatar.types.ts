export interface AvatarProps {
  src?: string;
  alt?: string;
  size?: number;
  fallback?: string;
  className?: string;
}