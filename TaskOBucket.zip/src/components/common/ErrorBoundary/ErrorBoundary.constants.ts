export const ERROR_MESSAGES = {
  title: 'Something went wrong',
  description: "We're sorry, but something unexpected happened.",
  reloadButton: 'Reload Page'
} as const;