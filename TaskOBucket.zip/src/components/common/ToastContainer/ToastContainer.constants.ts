export const DEFAULT_CLASS_NAME = '';
export const TOAST_CONTAINER_POSITION = 'fixed top-4 right-4 z-50 space-y-2 max-w-sm';