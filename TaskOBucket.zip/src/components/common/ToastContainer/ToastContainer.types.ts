export interface ToastContainerProps {
  className?: string;
}

export interface ToastContainerPosition {
  top?: string;
  bottom?: string;
  left?: string;
  right?: string;
}