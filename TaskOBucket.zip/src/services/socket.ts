// Placeholder socket client
export const socket = { on: () => {}, emit: () => {}, disconnect: () => {} }
