import { ProjectList } from '../projects/ProjectList'

export function Board() {
  return (
  <ProjectList /> 
  )
}
