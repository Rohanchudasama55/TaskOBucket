export const availableUsers = [
  { id: "current-user", name: "Tom Cook", initials: "TC", tag: "(Me)" },
  { id: "user-2", name: "Sarah Johnson", initials: "SJ" },
  { id: "user-3", name: "Mike Chen", initials: "MC" },
  { id: "user-4", name: "Jessica Lee", initials: "JL" },
  { id: "user-5", name: "David Kumar", initials: "DK" },
];

