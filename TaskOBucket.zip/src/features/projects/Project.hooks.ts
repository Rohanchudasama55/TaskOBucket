import type { CreateProjectRequest } from "./projectApi";

export interface CreateProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: CreateProjectRequest) => void;
  isLoading?: boolean;
}

export interface FormData extends CreateProjectRequest {
  key: string;
  leadId: string;
  teamMembers: string[];
}

export interface StateFormData {
  name: string;
  description: string;
  ownerId: string;
  key: string;
  leadId: string;
  teamMembers: string[];
}
