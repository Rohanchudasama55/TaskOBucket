import { MainLayout } from "../../layouts/MainLayout";
import TeamsPage from "./Teams.page";

export function TeamsMember() {
  return (
    <MainLayout>
      <TeamsPage />
    </MainLayout>
  );
}
