import { KanbanBoard } from '../../components/kanban';

export function IssuesPage() {
  return (
      <KanbanBoard />
  );
}