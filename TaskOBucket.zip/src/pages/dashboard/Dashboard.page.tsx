import ProjectAnalyticsDashboard from './Dashboard'

export function DashboardPage() {
  return (
    <>
     <ProjectAnalyticsDashboard />
    </>
  )
}