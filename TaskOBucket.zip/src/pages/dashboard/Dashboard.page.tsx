import { MainLayout } from '../../layouts/MainLayout'

export function DashboardPage() {
  return (
    <MainLayout>
      DASHBOARD
    </MainLayout>
  )
}