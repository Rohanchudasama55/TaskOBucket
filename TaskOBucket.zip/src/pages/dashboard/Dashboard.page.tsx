import { MainLayout } from '../../layouts/MainLayout'
import ProjectAnalyticsDashboard from './Dashboard'

export function DashboardPage() {
  return (
    <>
     <ProjectAnalyticsDashboard />
    </>
  )
}