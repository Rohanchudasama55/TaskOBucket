import { SprintKanbanBoard } from "./SprintKanbanBoard"


export const SprintsPage = () => {
  return (
    <SprintKanbanBoard />
  )
}
