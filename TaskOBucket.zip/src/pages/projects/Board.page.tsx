import { Board } from '../../features/board/Board'

export function BoardPage() {
  return (
      <Board />
  )
}