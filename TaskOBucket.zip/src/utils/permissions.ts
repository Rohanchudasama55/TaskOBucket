export const canEditProject = (userId?: string) => !!userId
